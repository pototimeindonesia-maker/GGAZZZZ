# POTOTIME WebView (Android)

A simple Android app wrapping your website in a WebView, opening:
`https://buatmomen.id/user/login.php`

## Build locally
1. Install Android Studio Flamingo/Arctic Fox or newer
2. Open this folder and run the `assembleDebug` Gradle task

## Build on GitHub Actions
Push this repository to GitHub **as-is**. The workflow at `.github/workflows/android.yml` will build a **debug APK** on every push to `main` or via the **Run workflow** button.

After it finishes, download the artifact `POTOTIME-Android-Debug-APK` → `app-debug.apk`.

## Change URL
Edit `app/src/main/res/values/strings.xml` → `<string name="site_url">...</string>`
